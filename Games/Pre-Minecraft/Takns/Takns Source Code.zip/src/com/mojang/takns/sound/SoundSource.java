package com.mojang.takns.sound;

public interface SoundSource
{
    public float getXSoundPos();
    public float getYSoundPos();
}